$(function(){
  $('.nano').nanoScroller({
    preventPageScrolling: true
  });
});

